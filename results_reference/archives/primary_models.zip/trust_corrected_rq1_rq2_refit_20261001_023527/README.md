Corrected RQ1/RQ2 refit. Expanded Claude provenance exclusion is the primary analysis. Core direct-disclosure exclusion is the sensitivity analysis. Agentic rows were not relabelled.
