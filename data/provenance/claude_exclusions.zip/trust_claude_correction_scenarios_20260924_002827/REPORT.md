# Claude provenance correction scenarios

Generated: 2026-09-24T06:28:27Z  
Tool version: 1.0.0

This audit separates two correction scenarios. It does not change the project
or fit any model.

## Core correction

The core scenario excludes stored-model human PRs with either an explicit
Claude authorship pattern or a manually reviewed direct authorship/assistance
disclosure.

- Excluded model-human PRs: 169
- Resolved exclusions: 139
- Affected repositories: 50

## Expanded correction

The expanded scenario adds model-human PRs whose head branch starts with
`claude/`. These rows remain separate in `03_expanded_branch_only.csv` so the
branch rule can be evaluated as a sensitivity decision.

- Excluded model-human PRs: 1,337
- Resolved exclusions: 1,250
- Affected repositories: 139

Plain mentions of Claude Code in a PR description are not exclusions.

No model was fitted. No network request was made. No project file was modified.
