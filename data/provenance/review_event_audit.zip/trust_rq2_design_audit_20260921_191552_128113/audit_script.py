#!/usr/bin/env python3
"""Trust Paper: local RQ2 design audit, Python 3.9+, no model fits or network.

Writes a new Desktop directory and ZIP. Source files are read only. The
candidate 24h flag uses terminal timestamps, NOT verified reopen histories.
"""
import argparse
from collections import Counter, defaultdict
import csv
from datetime import datetime, timedelta, timezone
import gzip
import hashlib
import importlib.util
import json
from pathlib import Path
import sqlite3
import sys
import time
import zipfile

sys.dont_write_bytecode = True
VERSION = '2026-09-22-v1'
ROOT_DEFAULT = Path('/Users/umutzengin/Desktop/Courses/trust_paper_aidev76_v5')
INPUT_REL = 'data/05_model_inputs/phase_b5/9559840112a4/phase_b5_pr_model_input.csv'
DB_REL = 'data/02_github_raw/phase_b4/checkpoints/phase_b4_hydration_state.sqlite'
MANIFEST_REL = 'data/04_cohorts/phase_b3/b3_final_pr_hydration_manifest.parquet'
EXPECTED_SHA = '81c26c946369f011f9bee11a0b94276c8fafa910006a3ea394490fc593f0781c'
READER_SHA = '08668b7e9f2b72808f080e758d5fdd504e86b5337693c92e14c0aa8dadabd4c7'
CUTOFF = datetime(2026, 3, 31, 23, 59, 59, tzinfo=timezone.utc)
COMPONENTS = ('reviews', 'review_comments', 'issue_comments')
SHORT = dict(reviews='formal', review_comments='inline', issue_comments='issue')
COPY_FIELDS = ('pr_key repository repository_id pr_number source agent_family created_at '
               'historical_status_at_cutoff files_changed log1p_files_changed test_file_presence '
               'description_word_count log1p_description_word_count strict_human_candidate '
               'candidate_spec_a_complete_case rq2_exposure_model_eligible').split()


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def ts(value):
    if value in (None, ''):
        return None
    try:
        value = datetime.fromisoformat(str(value).replace('Z', '+00:00'))
        return value.astimezone(timezone.utc) if value.tzinfo else None
    except (ValueError, TypeError, OverflowError):
        return None


def iso(value):
    return value.isoformat() if value else ''


def truth(value):
    if str(value).lower() not in ('true', 'false', '1', '0'):
        raise ValueError('Unexpected boolean value')
    return str(value).lower() in ('true', '1')


def actor(user, author):
    user = user if isinstance(user, dict) else {}
    login = str(user.get('login') or '').strip()
    if not login:
        return 'MISSING_ACTOR'
    if str(user.get('type') or '').lower() == 'bot' or login.lower().endswith('[bot]'):
        return 'BOT'
    if not author:
        return 'MISSING_AUTHOR'
    if login.casefold() == author.casefold():
        return 'PR_AUTHOR'
    return 'EXTERNAL_NONBOT'


def quantile(values, p):
    if not values:
        return None
    values = sorted(values)
    x = (len(values) - 1) * p
    lo = int(x)
    hi = min(lo + 1, len(values) - 1)
    return values[lo] + (values[hi] - values[lo]) * (x - lo)


def write_csv(path, rows, fields):
    opener = gzip.open if str(path).endswith('.gz') else open
    mode = 'wt' if str(path).endswith('.gz') else 'w'
    with opener(path, mode, encoding='utf-8', newline='') as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        w.writerows(rows)


def load_authors(root):
    reader = root / 'src/parquet_lite.py'
    if sha(reader) != READER_SHA:
        raise ValueError('Local Parquet reader differs from the inspected code; send this message.')
    name = '_trust_rq2_local_parquet'
    spec = importlib.util.spec_from_file_location(name, reader)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    data = mod.ParquetFileLite(mod.LocalSource(root / MANIFEST_REL))
    authors = {}
    for batch in data.iter_batches(['canonical_pr_key', 'user_login']):
        for key, login in zip(batch['canonical_pr_key'], batch['user_login']):
            key = str(key)
            if key in authors:
                raise ValueError('Duplicate PR in author manifest')
            authors[key] = str(login or '').strip()
    return authors


class Audit:
    def __init__(self, root, output, expected_sha=EXPECTED_SHA, authors_override=None):
        self.root, self.out = Path(root).resolve(), Path(output).resolve()
        if self.root == self.out or self.root in self.out.parents:
            raise ValueError('Report directory must be outside the project')
        self.expected_sha = expected_sha
        self.authors_override = authors_override  # synthetic test fixtures only
        self.issues = Counter()
        self.examples = []
        self.stats = Counter()
        self.rows, self.meta, self.tasks = {}, {}, {}
        self.counts = defaultdict(Counter)
        self.first = {}
        self.seen_components = set()
        self.bad_components = set()
        self.review_times = {}

    def log(self, message):
        print(datetime.now().isoformat(timespec='seconds') + ' ' + message, flush=True)

    def issue(self, reason, key='', component='', detail=''):
        self.issues[reason] += 1
        if self.issues[reason] <= 20:
            self.examples.append(dict(reason=reason, pr_key=key, component=component, detail=detail))

    def payload(self, relative):
        path = (self.root / relative).resolve()
        path.relative_to(self.root)
        with gzip.open(path, 'rt', encoding='utf-8') as f:
            return json.load(f)

    def responses(self, con, component):
        sql = '''SELECT t.pr_key,r.body_path FROM responses r JOIN tasks t ON t.task_id=r.task_id
                 WHERE r.component=? AND r.http_status BETWEEN 200 AND 299
                 ORDER BY t.pr_key,r.response_id'''
        last = time.monotonic()
        n = 0
        for response in con.execute(sql, (component,)):
            key = response['pr_key']
            if key not in self.rows:
                continue
            n += 1
            if time.monotonic() - last >= 15:
                self.log('%s: %s files checked' % (component, format(n, ',')))
                last = time.monotonic()
            try:
                item = self.payload(response['body_path'])
                if not isinstance(item, dict if component == 'pull_metadata' else list):
                    raise ValueError('Unexpected payload type')
            except (OSError, EOFError, ValueError, UnicodeError) as e:
                self.bad_components.add((key, component))
                self.issue('unreadable_or_invalid_payload', key, component, type(e).__name__)
                continue
            self.seen_components.add((key, component))
            yield key, item
        self.stats[component + '_files_checked'] = n
        self.log('Completed %s: %s files' % (component, format(n, ',')))

    def metadata(self, con):
        for key, item in self.responses(con, 'pull_metadata'):
            row = self.rows[key]
            created, merged, closed = [ts(item.get(k)) for k in ('created_at', 'merged_at', 'closed_at')]
            frozen = ts(row['created_at'])
            repo = ((item.get('base') or {}).get('repo') or {})
            valid_id = (str(repo.get('id')) == row['repository_id'] and
                        str(item.get('number')) == row['pr_number'])
            if not valid_id:
                self.issue('metadata_identity_mismatch', key, 'pull_metadata')
            raw_author = str((item.get('user') or {}).get('login') or '').strip()
            agreed_author = bool(raw_author and self.authors[key] and raw_author.casefold() == self.authors[key].casefold())
            if not agreed_author:
                self.issue('manifest_raw_author_mismatch_or_missing', key, 'pull_metadata')
            status = 'MERGED' if merged and merged <= CUTOFF else 'CLOSED_UNMERGED' if closed and closed <= CUTOFF else 'OPEN'
            status_agrees = status == row['historical_status_at_cutoff']
            if not status_agrees:
                self.issue('cutoff_status_disagrees_with_terminal_fields', key, 'pull_metadata')
            decision = merged if status == 'MERGED' else closed if status == 'CLOSED_UNMERGED' else None
            metadata_ok = bool(created and frozen and valid_id and status_agrees and created <= CUTOFF)
            if any(item.get(f) not in ('', None) and ts(item.get(f)) is None for f in ('created_at','merged_at','closed_at')):
                metadata_ok = False
                self.issue('invalid_metadata_timestamp', key, 'pull_metadata')
            delta = (created - frozen).total_seconds() if created and frozen else None
            if delta != 0:
                self.stats['creation_different'] += 1
                self.issue('creation_clock_difference', key, 'pull_metadata', str(delta))
            if decision and (not created or decision < created):
                metadata_ok = False
                self.issue('terminal_before_creation', key, 'pull_metadata')
            rec = dict(created=created, frozen=frozen, merged=merged, closed=closed, decision=decision,
                       status=status, metadata_ok=metadata_ok, author_agrees=agreed_author,
                       delta_seconds=delta)
            if key in self.meta and self.meta[key] != rec:
                self.bad_components.add((key, 'pull_metadata'))
                self.issue('conflicting_metadata_snapshots', key, 'pull_metadata')
            else:
                self.meta[key] = rec

    def event_rows(self, con, component, writer):
        previous, seen = None, {}
        short = SHORT[component]
        for key, items in self.responses(con, component):
            if key != previous:
                previous, seen = key, {}
            m = self.meta.get(key)
            for item in items:
                if not isinstance(item, dict):
                    self.bad_components.add((key, component))
                    self.issue('event_not_object', key, component)
                    continue
                ident = str(item.get('id') or item.get('node_id') or '')
                stamp = ts(item.get('submitted_at' if component == 'reviews' else 'created_at'))
                state = str(item.get('state') or '').upper()
                category = actor(item.get('user'), self.authors[key])
                parent = str(item.get('pull_request_review_id') or '')
                signature = (iso(stamp), state, category, parent)
                if ident in seen and ident:
                    self.stats['duplicate_event_rows'] += 1
                    if seen[ident] != signature:
                        self.bad_components.add((key, component))
                        self.issue('conflicting_duplicate', key, component, ident)
                    continue
                if not ident:
                    self.bad_components.add((key, component))
                    self.issue('event_without_id', key, component)
                seen[ident] = signature
                if component == 'reviews':
                    self.review_times[(key, ident)] = stamp
                    self.stats['formal_current_snapshot_state_' + (state or 'UNKNOWN')] += 1
                effective = stamp
                parent_status = 'not_applicable'
                if component == 'review_comments' and parent:
                    if (key, parent) in self.review_times:
                        submitted = self.review_times[(key, parent)]
                        if stamp and submitted:
                            effective = max(stamp, submitted)
                            parent_status = 'submitted'
                            if effective != stamp:
                                self.stats['inline_creation_precedes_parent_submission'] += 1
                        else:
                            effective = None
                            parent_status = 'parent_not_timestamped'
                    else:
                        effective = None
                        parent_status = 'parent_not_found'
                elif component == 'review_comments':
                    effective = None
                    parent_status = 'parent_id_missing'
                writer.writerow(dict(pr_key=key, component=component, event_id=ident,
                                     recorded_timestamp=iso(stamp), effective_timestamp=iso(effective),
                                     actor_category=category, current_snapshot_state=state,
                                     parent_review_id=parent, parent_status=parent_status))
                self.stats[component + '_events_exported'] += 1
                if category in ('BOT', 'PR_AUTHOR'):
                    self.stats[component + '_excluded_' + category] += 1
                    continue
                # A pending review has no submitted event. Never infer its timing.
                if component == 'reviews' and state == 'PENDING' and stamp is None:
                    self.stats['pending_reviews_without_submission_excluded'] += 1
                    continue
                if component == 'reviews' and state == 'PENDING' and stamp is not None:
                    self.counts[key][short + '_uncertain_events'] += 1
                    self.issue('pending_review_has_submission_timestamp', key, component, ident)
                    continue
                if effective and effective > CUTOFF:
                    self.stats[component + '_after_cutoff'] += 1
                    continue
                if category != 'EXTERNAL_NONBOT' or effective is None:
                    self.counts[key][short + '_uncertain_events'] += 1
                    self.issue('unknown_actor_or_event_time', key, component, category + '/' + parent_status)
                    continue
                if not m or not m['created']:
                    continue
                c = self.counts[key]
                if effective < m['created']:
                    c[short + '_events_before_creation'] += 1
                    c[short + '_uncertain_events'] += 1
                    self.issue('external_event_before_raw_creation', key, component, ident)
                    continue
                c[short + '_by_cutoff'] += 1
                earliest = self.first.get((key, short))
                if earliest is None or effective < earliest:
                    self.first[(key, short)] = effective
                inside_raw = effective <= m['created'] + timedelta(hours=24)
                inside_frozen = bool(m['frozen'] and m['frozen'] <= effective <= m['frozen'] + timedelta(hours=24))
                if inside_raw:
                    c[short + '_first24_rawclock'] += 1
                if inside_frozen:
                    c[short + '_first24_frozenclock'] += 1
                if inside_raw != inside_frozen:
                    c[short + '_24h_clock_disagreement_events'] += 1
                d = m['decision']
                if d:
                    relation = 'pre' if effective < d else 'tie' if effective == d else 'post'
                    c[short + '_' + relation] += 1

    def available(self, key, component):
        return (self.tasks.get((key, component)) == 'COMPLETED' and
                (key, component) in self.seen_components and
                (key, component) not in self.bad_components)

    def exports(self):
        output = []
        design = Counter()
        repo_counts = defaultdict(Counter)
        durations = defaultdict(list)
        for key, row in self.rows.items():
            rec = dict(row)
            m, c = self.meta.get(key), self.counts[key]
            metadata_ok = bool(m and m['metadata_ok'] and self.available(key, 'pull_metadata'))
            author_ok = bool(m and m['author_agrees'])
            decision = m['decision'] if m else None
            resolved = bool(metadata_ok and decision and row['historical_status_at_cutoff'] != 'OPEN')
            duration = (decision - m['created']).total_seconds() / 3600 if resolved else None
            rec.update(raw_created_at=iso(m['created']) if m else '',
                       raw_merged_at=iso(m['merged']) if m else '', raw_closed_at=iso(m['closed']) if m else '',
                       raw_minus_frozen_creation_seconds=m['delta_seconds'] if m else '',
                       metadata_identity_and_time_valid=metadata_ok, manifest_raw_author_agree=author_ok,
                       candidate_resolution_timestamp=iso(decision), duration_to_resolution_hours=duration)
            measure_ok = {}
            for component, short in SHORT.items():
                measure_ok[short] = bool(metadata_ok and author_ok and self.available(key, component) and
                                         c[short + '_uncertain_events'] == 0)
                rec[short + '_measure_available'] = measure_ok[short]
                for suffix in ('pre','tie','post','by_cutoff','first24_rawclock','first24_frozenclock',
                               '24h_clock_disagreement_events','events_before_creation','uncertain_events'):
                    rec[short + '_' + suffix] = c[short + '_' + suffix]
                rec[short + '_first_external_event_at'] = iso(self.first.get((key, short)))
            eligible = resolved and measure_ok['formal']
            discussion_eligible = resolved and measure_ok['inline'] and measure_ok['issue']
            # This is only a candidate population. Latest terminal timestamps do
            # not establish that a PR was continuously open or open at hour 24.
            landmark_proxy = bool(eligible and duration > 24 and m['created'] + timedelta(hours=24) <= CUTOFF)
            landmark_observable_proxy = bool(metadata_ok and measure_ok['formal'] and
                m['created'] + timedelta(hours=24) <= CUTOFF and
                (decision is None or decision > m['created'] + timedelta(hours=24)))
            complete_a = truth(row['candidate_spec_a_complete_case'])
            rec.update(candidate_formal_resolution_eligible=eligible,
                       candidate_discussion_resolution_eligible=discussion_eligible,
                       candidate_formal_24h_terminal_proxy=landmark_proxy,
                       candidate_formal_24h_observable_terminal_proxy=landmark_observable_proxy,
                       candidate_formal_resolution_plus_A_available=eligible and complete_a,
                       formal_binary_predecision=int(c['formal_pre'] > 0) if eligible else '',
                       formal_binary_including_ties=int(c['formal_pre'] + c['formal_tie'] > 0) if eligible else '',
                       formal_binary_first24_proxy=int(c['formal_first24_rawclock'] > 0) if landmark_proxy else '')
            rec['discussion_binary_predecision'] = int(c['inline_pre'] + c['issue_pre'] > 0) if discussion_eligible else ''
            rec['first_formal_to_resolution_hours'] = ((decision-self.first[(key,'formal')]).total_seconds()/3600
                if eligible and c['formal_pre'] > 0 else '')
            # Counts are diagnostics; eligibility and missingness must be used
            # before interpreting a numerical zero as a measured absence.
            source, status = row['source'], row['historical_status_at_cutoff']
            design[('all_cohort', source, status)] += 1
            if landmark_observable_proxy:
                design[('formal_24h_observable_terminal_proxy', source, status)] += 1
            if duration is not None:
                durations[(source, status)].append(duration)
            for scope, ok in [('formal_resolution',eligible), ('formal_resolution_plus_A',eligible and complete_a),
                              ('formal_24h_terminal_proxy',landmark_proxy),('discussion_resolution',discussion_eligible)]:
                if not ok:
                    continue
                design[(scope, source, status)] += 1
                binary = int(c['formal_first24_rawclock'] > 0) if scope == 'formal_24h_terminal_proxy' else int(c['formal_pre'] > 0)
                if scope == 'discussion_resolution':
                    binary = int(c['inline_pre'] + c['issue_pre'] > 0)
                repo_counts[(scope, row['repository'])][(source, status, binary)] += 1
            if eligible:
                self.stats['eligible_formal_zero_duration'] += int(duration == 0)
                self.stats['eligible_formal_resolved_by24h'] += int(duration <= 24)
                self.stats['formal_binary_changes_if_ties_included'] += int(c['formal_pre'] == 0 and c['formal_tie'] > 0)
                if measure_ok['inline'] and measure_ok['issue']:
                    self.stats['eligible_complete_event_family_measurements'] += 1
                    f, i, q = c['formal_pre'] > 0, c['inline_pre'] > 0, c['issue_pre'] > 0
                    self.stats['pattern_formal%d_inline%d_issue%d' % (f, i, q)] += 1
                    rec['predecision_event_pattern'] = 'formal%d_inline%d_issue%d' % (f, i, q)
                else:
                    rec['predecision_event_pattern'] = 'unavailable'
            else:
                rec['predecision_event_pattern'] = 'unavailable'
            output.append(rec)
        fields = list(output[0])
        write_csv(self.out/'pr_design_inventory.csv.gz', output, fields)
        accounting = [dict(scope=a, source=b, status=c, prs=n) for (a,b,c),n in sorted(design.items())]
        write_csv(self.out/'population_accounting.csv', accounting, ['scope','source','status','prs'])
        support = []
        for (scope, repository), counter in sorted(repo_counts.items()):
            rec = dict(scope=scope, repository=repository)
            for source in ('human','agentic'):
                for status in ('MERGED','CLOSED_UNMERGED'):
                    for exposure in (0,1):
                        rec['%s_%s_review%d' % (source,status,exposure)] = counter[(source,status,exposure)]
            rec['both_sources'] = all(sum(n for (s,o,e),n in counter.items() if s == source) > 0 for source in ('human','agentic'))
            rec['both_outcomes'] = all(sum(n for (s,o,e),n in counter.items() if o == status) > 0 for status in ('MERGED','CLOSED_UNMERGED'))
            rec['review_variation_in_each_source'] = all(sum(n for (s,o,e),n in counter.items() if s == source and e == exposure) > 0 for source in ('human','agentic') for exposure in (0,1))
            support.append(rec)
        support_fields = list(support[0]) if support else ['scope','repository']
        write_csv(self.out/'repository_support.csv', support, support_fields)
        durations_out = []
        for (source,status),values in sorted(durations.items()):
            durations_out.append(dict(source=source,status=status,prs=len(values),
                                     p25_hours=quantile(values,.25),median_hours=quantile(values,.5),
                                     p75_hours=quantile(values,.75),resolved_by24h=sum(x <= 24 for x in values)))
        write_csv(self.out/'resolution_duration_summary.csv', durations_out,
                  ['source','status','prs','p25_hours','median_hours','p75_hours','resolved_by24h'])
        return dict(cohort_prs=len(output), population_accounting=accounting,
                    candidate_repository_support=[dict(scope=scope,repositories=sum(r['scope']==scope for r in support),
                    both_sources_and_outcomes=sum(r['scope']==scope and r['both_sources'] and r['both_outcomes'] for r in support),
                    both_sources_outcomes_and_review_variation=sum(r['scope']==scope and r['both_sources'] and r['both_outcomes'] and r['review_variation_in_each_source'] for r in support))
                    for scope in sorted({r['scope'] for r in support})])

    def run(self):
        input_path = self.root / INPUT_REL
        input_sha = sha(input_path)
        if input_sha != self.expected_sha:
            raise ValueError('Frozen input differs from the inspected ZIP. Send this message before proceeding.')
        with input_path.open(encoding='utf-8-sig',newline='') as f:
            reader = csv.DictReader(f)
            if set(COPY_FIELDS) - set(reader.fieldnames or []):
                raise ValueError('Required model-input columns are missing')
            for row in reader:
                key = row['pr_key']
                if key in self.rows or not key:
                    raise ValueError('Empty or duplicate model-input PR key')
                self.rows[key] = {k:row[k] for k in COPY_FIELDS}
        self.authors = self.authors_override if self.authors_override is not None else load_authors(self.root)
        if set(self.rows) != set(self.authors):
            raise ValueError('Author manifest and model-input PR keys differ')
        self.log('Read %s PRs and frozen author identities' % format(len(self.rows),','))
        self.out.mkdir(parents=True,exist_ok=False)
        provenance = dict(input_sha256=input_sha, script_sha256=sha(Path(__file__)),
                          author_source=MANIFEST_REL if self.authors_override is None else 'synthetic_fixture',
                          author_manifest_sha256=sha(self.root/MANIFEST_REL) if self.authors_override is None else None)
        con = sqlite3.connect((self.root/DB_REL).as_uri()+'?mode=ro',uri=True)
        con.row_factory = sqlite3.Row
        try:
            con.execute('PRAGMA query_only=ON')
            con.execute('BEGIN')
            inventory = [dict(r) for r in con.execute('SELECT component,status,COUNT(*) AS tasks FROM tasks GROUP BY component,status')]
            for r in con.execute('SELECT pr_key,component,status FROM tasks'):
                if r['pr_key'] in self.rows:
                    self.tasks[(r['pr_key'],r['component'])] = r['status']
            self.metadata(con)
            with gzip.open(self.out/'event_timing_inventory.csv.gz','wt',encoding='utf-8',newline='') as f:
                w=csv.DictWriter(f,fieldnames=['pr_key','component','event_id','recorded_timestamp','effective_timestamp',
                                               'actor_category','current_snapshot_state','parent_review_id','parent_status'])
                w.writeheader()
                for component in COMPONENTS:
                    self.event_rows(con,component,w)
        finally:
            con.close()
        report = self.exports()
        write_csv(self.out/'issue_examples.csv',self.examples,['reason','pr_key','component','detail'])
        if sha(input_path) != input_sha:
            raise ValueError('Source input changed during the audit; output must not be used')
        report.update(version=VERSION,status='COMPLETED_DESIGN_REVIEW_REQUIRED',cutoff=iso(CUTOFF),
                      models_fitted=0,network_requests=0,source_files_modified=False,
                      issues=dict(self.issues),event_diagnostics=dict(self.stats),
                      provenance=provenance,endpoint_task_inventory=inventory,
                      limitations=[
                          'Candidate rows are NOT an approved final analysis population.',
                          'Raw GitHub creation times are a candidate audit clock, not a mutation of frozen input.',
                          '24h terminal proxy does NOT verify that a PR was open continuously or at hour 24.',
                          'Latest metadata cannot reconstruct reopen histories or historical review decisions.',
                          'Current snapshot review state is NOT necessarily the state at the analysis cutoff.',
                          'A non-bot account is not proof of a human reviewer.',
                          'A zero event count is interpretable only when the corresponding measure_available flag is true.',
                          'Same-second review and resolution have uncertain ordering; strict predecision counts exclude ties.',
                          'Inline effective time is max(comment creation,parent review submission); unlinked comments are uncertain.',
                          'Repository support counts are diagnostics, not separation checks or model fit results.',
                          'No OR, CI, p-value, or predictive performance is calculated.'])
        (self.out/'summary.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
        (self.out/'audit_script.py').write_bytes(Path(__file__).read_bytes())
        archive = self.out.with_suffix('.zip')
        with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED) as z:
            for path in sorted(self.out.iterdir()):
                z.write(path,self.out.name+'/'+path.name)
        self.log('Completed. No models fitted; no network requests; no source files modified.')
        print('UPLOAD THIS ZIP: '+str(archive),flush=True)
        return report


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root',type=Path,default=ROOT_DEFAULT)
    parser.add_argument('--output-parent',type=Path,default=Path.home()/'Desktop')
    args=parser.parse_args()
    stamp=datetime.now().strftime('%Y%m%d_%H%M%S_%f')
    Audit(args.root,args.output_parent/('trust_rq2_design_audit_'+stamp)).run()


if __name__ == '__main__':
    main()
